﻿#include <windows.h>
#include <commdlg.h>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>

std::string idToSignature(long long id) {
    std::ostringstream oss;
    unsigned char bytes[10] = { 0 };
    for (int i = 0; i < 10 && id > 0; i++) {
        bytes[i] = id & 0xFF;
        id >>= 8;
    }
    for (int i = 0; i < 10; i++) {
        oss << std::uppercase << std::hex << std::setw(2)
            << std::setfill('0') << (int)bytes[i];
        if (i != 9) oss << " ";
    }
    return oss.str();
}

void writeLineToFile(const std::wstring& path, const std::string& line, bool append = true) {
    HANDLE hFile = CreateFileW(
        path.c_str(),
        GENERIC_WRITE,
        0,
        NULL,
        append ? OPEN_EXISTING : CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (hFile == INVALID_HANDLE_VALUE) {
        std::wcerr << L"Не удалось открыть файл: " << path << std::endl;
        return;
    }

    if (append) SetFilePointer(hFile, 0, NULL, FILE_END);

    DWORD written;
    std::string lineWithNewline = line + "\n";
    WriteFile(hFile, lineWithNewline.c_str(), (DWORD)lineWithNewline.size(), &written, NULL);
    CloseHandle(hFile);
}

void processFile(const std::wstring& inputFile, const std::wstring& outputFile) {
    std::wifstream in(inputFile);
    if (!in.is_open()) {
        std::wcerr << L"Не удалось открыть входной файл: " << inputFile << std::endl;
        return;
    }

    HANDLE hOut = CreateFileW(outputFile.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hOut == INVALID_HANDLE_VALUE) {
        std::wcerr << L"Не удалось создать выходной файл: " << outputFile << std::endl;
        in.close();
        return;
    }
    CloseHandle(hOut);

    std::wstring line;
    while (std::getline(in, line)) {
        size_t pos = line.find(L"=");
        if (pos != std::wstring::npos) {
            try {
                long long id = std::stoll(std::string(line.begin() + pos + 1, line.end()));
                std::string signature = idToSignature(id);
                std::string outLine = std::string(line.begin(), line.end()) + " Signatures " + signature + " [Processed by ApexConverter v1.0]";
                writeLineToFile(outputFile, outLine);
            }
            catch (...) {
                std::string outLine = std::string(line.begin(), line.end()) + " [Ошибка: не удалось распознать ID]";
                writeLineToFile(outputFile, outLine);
            }
        } else {
            std::string outLine(line.begin(), line.end());
            writeLineToFile(outputFile, outLine);
        }
    }

    in.close();
    std::wcout << L"Файл обработан. Результат сохранён в " << outputFile << std::endl;
}

std::wstring openFileDialog() {
    OPENFILENAMEW ofn;
    wchar_t szFile[MAX_PATH] = {0};
    ZeroMemory(&ofn, sizeof(ofn));

    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"Text Files\0*.txt\0All Files\0*.*\0";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    ofn.lpstrTitle = L"Выберите входной файл";

    if (GetOpenFileNameW(&ofn)) {
        return szFile;
    }
    return L"";
}

std::wstring saveFileDialog() {
    OPENFILENAMEW ofn;
    wchar_t szFile[MAX_PATH] = {0};
    ZeroMemory(&ofn, sizeof(ofn));

    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"Text Files\0*.txt\0All Files\0*.*\0";
    ofn.Flags = OFN_OVERWRITEPROMPT;
    ofn.lpstrTitle = L"Сохранить файл как";

    if (GetSaveFileNameW(&ofn)) {
        return szFile;
    }
    return L"";
}

int wmain() {
    setlocale(LC_ALL, "Russian");

    std::wcout << L"Выберите режим:\n";
    std::wcout << L"1 - Ввести ID вручную\n";
    std::wcout << L"2 - Загрузить файл\n";

    int mode;
    std::wcin >> mode;

    if (mode == 1) {
        long long id;
        std::wcout << L"Введите ID: ";
        std::wcin >> id;
        std::string signature = idToSignature(id);
        std::wcout << L"Signature: ";
        for (char c : signature) std::wcout << c;
        std::wcout << std::endl;
    }
    else if (mode == 2) {
        std::wstring inputFile = openFileDialog();
        if (inputFile.empty()) {
            std::wcout << L"Файл не выбран.\n";
            return 0;
        }

        std::wstring outputFile = saveFileDialog();
        if (outputFile.empty()) {
            std::wcout << L"Файл не выбран для сохранения.\n";
            return 0;
        }

        processFile(inputFile, outputFile);
    }
    else {
        std::wcout << L"Неверный выбор.\n";
    }

    return 0;
}
